from django.contrib import admin
from employee.models import Employee, EmployeeTask, EmployeeData

# Register your models here.
admin.site.register(Employee)
admin.site.register(EmployeeTask)
admin.site.register(EmployeeData)