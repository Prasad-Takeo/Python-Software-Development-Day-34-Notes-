from rest_framework import serializers
from employee.models import Employee, EmployeeTask, EmployeeData

class EmployeeDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeData
        fields = "__all__"

class EmployeeSerializer(serializers.ModelSerializer):
    tasks = serializers.StringRelatedField(many=True,read_only=True)
    data = serializers.StringRelatedField(many=True,read_only=True)

    class Meta:
        model = Employee
        fields = "__all__"


class EmployeeTaskSerializer(serializers.ModelSerializer):
    employee = serializers.StringRelatedField(many=False, read_only=True)
    class Meta:
        model = EmployeeTask
        fields = "__all__"





"""
generic
APIview - basic
ViewSet

"""